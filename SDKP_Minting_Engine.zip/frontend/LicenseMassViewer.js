import { useContractRead } from 'wagmi';

export function LicenseMassViewer({ tokenId }) {
  const { data, isLoading, error } = useContractRead({
    address: 'YOUR_CONTRACT_ADDRESS',
    abi: [
      {
        name: 'computeMass',
        type: 'function',
        stateMutability: 'view',
        inputs: [{ name: 'id', type: 'uint256' }],
        outputs: [{ name: '', type: 'int256' }],
      },
    ],
    functionName: 'computeMass',
    args: [tokenId],
  });

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return <div>Mass of License {tokenId}: {data.toString()}</div>;
}
