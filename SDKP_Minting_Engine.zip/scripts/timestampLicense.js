const { ethers } = require("hardhat");

async function main() {
    const license = await ethers.getContractAt("FTPOnChainLicense1155", "YOUR_CONTRACT_ADDRESS");
    const tx = await license.emitTimeSeal(0); // Example for tokenId 0
    await tx.wait();
    console.log("Timestamp emitted and notarized via Chainlink (simulated).");
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
