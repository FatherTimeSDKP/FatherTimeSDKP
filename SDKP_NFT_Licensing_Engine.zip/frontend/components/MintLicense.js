import { usePrepareContractWrite, useContractWrite } from 'wagmi';
import abi from '../abi/FTPOnChainLicense1155.json';

const CONTRACT = '0x8fcD2CaFD30333F967e1fDdF05AEfb12e8aFc221';

export function MintLicense({ tokenId, address }) {
  const { config } = usePrepareContractWrite({
    address: CONTRACT,
    abi,
    functionName: 'mint',
    args: [address, tokenId, 1, '0x'],
  });
  const { write } = useContractWrite(config);
  return <button onClick={() => write?.()}>Mint License #{tokenId}</button>;
}