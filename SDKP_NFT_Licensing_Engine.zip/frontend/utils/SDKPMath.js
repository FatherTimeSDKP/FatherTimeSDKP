export function calculateSDKPMass(N, S, alpha, beta, gamma) {
  return gamma * N * S + beta * S + alpha * N;
}